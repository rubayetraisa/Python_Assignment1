numbers=['4, 8, 7, 4,3,6,2,1,9']

if 6 in numbers:
    print("Exists")
else:
    print("Doesn't exist")
    
