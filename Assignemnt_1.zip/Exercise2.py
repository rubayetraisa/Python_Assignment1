name= "Hello there"
print(type(name))