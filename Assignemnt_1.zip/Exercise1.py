name= "Hello there"
print(len(name))