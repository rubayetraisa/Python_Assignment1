def func(n):
    if (n%3)==0 and (n%5)==0:
        print("FizzBuzz")
    elif n%3==0:
        print("Fizz")
    elif n%5==0:
        print("Buzz")
    else:
        print("Not a Fizz-buzz number")


n=input("Enter a number: ")
        
func(int(n))